package com.example.sushi_delle_vette;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Trova il pulsante dal layout XML utilizzando l'ID
        Button homebtn= findViewById(R.id.homebtn);

        // Aggiungi un'azione di click al pulsante
        homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Crea un Intent per avviare l'Activity "Home"
                Intent intent = new Intent(MainActivity.this, Home.class);
                // Avvia l'Activity "Home"
                startActivity(intent);
            }
        });
    }
}